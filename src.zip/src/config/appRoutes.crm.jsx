import { lazy } from "react";

const LeadDashboard = lazy(() => import("../features/crm/pages/LeadDashboard"));
const LeadList = lazy(() => import("../features/crm/pages/LeadList"));
const LeadPipeline = lazy(() => import("../features/crm/pages/LeadPipeline"));
const CampaignList = lazy(() => import("../features/crm/pages/CampaignList"));

export const publicRoutes = [
  // Login, Register, OTP...
];

export const protectedRoutes = [
  {
    key: "crm-dashboard",
    path: "/crm/dashboard",
    element: <LeadDashboard />,
    showInSidebar: true,
  },
  {
    key: "crm-leads",
    path: "/crm/leads",
    element: <LeadList />,
    showInSidebar: true,
  },
  {
    key: "crm-pipeline",
    path: "/crm/pipeline",
    element: <LeadPipeline />,
    showInSidebar: true,
  },
  {
    key: "crm-campaigns",
    path: "/crm/campaigns",
    element: <CampaignList />,
    showInSidebar: true,
  },
];