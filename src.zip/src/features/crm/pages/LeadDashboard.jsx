import { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
    Alert, Box, Card, CardContent, Typography, Button, Chip, Stack, Avatar,
    Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, TextField,
    Grid, LinearProgress, Radio, RadioGroup, Table, TableBody, TableCell, TableContainer,
    TableHead, TableRow, Paper, Divider, CircularProgress,
} from '@mui/material';
import {
    Add as AddIcon,
    Assessment as PipelineIcon,
    Business as BusinessIcon,
    Campaign as CampaignIcon,
    ContentCopy as CopyIcon,
    EventAvailable as EventIcon,
    Groups as GroupsIcon,
    TrendingUp as TrendingUpIcon,
    Rule as RuleIcon,
    Save as SaveIcon,
    WarningAmber as WarningIcon,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip as ChartTooltip } from 'recharts';
import {
    addLeadActivity, deleteLead, getLeads, getLeadSummary,
    getScoreRules, saveScoreRules, updateLead,
} from '../state/leadSlice';
import { getOrganisation } from '../../organisation/state/orgSlice';

const STATUS_CONFIG = {
    new: { color: '#6366f1', bg: '#eef2ff', label: 'New' },
    contact_attempted: { color: '#f59e0b', bg: '#fffbeb', label: 'Contact Attempted' },
    connected: { color: '#0891b2', bg: '#ecfeff', label: 'Connected' },
    requirement_discussion: { color: '#8b5cf6', bg: '#f5f3ff', label: 'Requirement Discussion' },
    quotation_sent: { color: '#ec4899', bg: '#fdf2f8', label: 'Quotation Sent' },
    negotiation: { color: '#f97316', bg: '#fff7ed', label: 'Negotiation' },
    positive_response: { color: '#10b981', bg: '#ecfdf5', label: 'Positive Response' },
    po_received: { color: '#0284c7', bg: '#eff6ff', label: 'PO Received' },
    invoice_generated: { color: '#7c3aed', bg: '#f5f3ff', label: 'Invoice Generated' },
    closed_won: { color: '#16a34a', bg: '#dcfce7', label: 'Closed Won' },
    closed_lost: { color: '#dc2626', bg: '#fee2e2', label: 'Closed Lost' },
};

const DEFAULT_SCORE_RULES = {
    stageWeights: {
        new: 10,
        contact_attempted: 20,
        connected: 35,
        requirement_discussion: 50,
        quotation_sent: 65,
        negotiation: 75,
        positive_response: 85,
        po_received: 92,
        invoice_generated: 96,
        closed_won: 100,
        closed_lost: 0,
    },
    highValueBudget: 100000,
    highValueBonus: 8,
    contactBonus: 5,
    ownerBonus: 5,
    productBonus: 4,
    closingSoonBonus: 6,
    overduePenalty: 12,
    stalePenalty: 10,
    hotScore: 80,
    warmScore: 55,
    staleDays: 14,
};

const STAGE_WEIGHT = {
    new: 10,
    contact_attempted: 20,
    connected: 35,
    requirement_discussion: 50,
    quotation_sent: 65,
    negotiation: 75,
    positive_response: 85,
    po_received: 92,
    invoice_generated: 96,
    closed_won: 100,
    closed_lost: 0,
};

const terminalStatuses = new Set(['closed_won', 'closed_lost']);

const mergeScoreRules = (rules) => ({
    ...DEFAULT_SCORE_RULES,
    ...(rules || {}),
    stageWeights: { ...DEFAULT_SCORE_RULES.stageWeights, ...(rules?.stageWeights || {}) },
});

const normalizeComparable = (value) => String(value || '').trim().toLowerCase();
const normalizePhone = (value) => String(value || '').replace(/\D/g, '');

const GlassCard = styled(Card)(() => ({
    background: 'rgba(255,255,255,0.94)',
    border: '1px solid #e5e7eb',
    borderRadius: '14px',
    boxShadow: '0 8px 28px rgba(15,23,42,0.06)',
}));

const formatMoney = (amount, currency = 'INR') => {
    const value = Number(amount || 0);
    if (!value) return `${currency} 0`;
    return `${currency} ${value.toLocaleString('en-IN')}`;
};

const getDaysBetween = (dateValue, baseDate = new Date()) => {
    if (!dateValue) return null;
    const date = new Date(dateValue);
    if (Number.isNaN(date.getTime())) return null;
    return Math.ceil((date.setHours(0, 0, 0, 0) - new Date(baseDate).setHours(0, 0, 0, 0)) / 86400000);
};

const getUserLabel = (user) => {
    if (!user) return '';
    return user.name || user.full_name || user.username || user.email || '';
};

const getOwnerLabel = (lead) =>
    lead?.owner?.name ||
    lead?.owner?.full_name ||
    lead?.assigned_to?.name ||
    lead?.assigned_user?.name ||
    lead?.owner_name ||
    lead?.assigned_to_name ||
    'Unassigned';

const getOpenFollowUps = (lead) => (lead.follow_ups || []).filter((item) => !item.is_done);

const getFollowUpCounts = (lead) => {
    const open = getOpenFollowUps(lead);
    const dueToday = open.filter((item) => getDaysBetween(item.due_date) === 0).length;
    const overdue = open.filter((item) => {
        if (item.is_overdue) return true;
        const days = getDaysBetween(item.due_date);
        return days !== null && days < 0;
    }).length;

    return { open: open.length, dueToday, overdue };
};

export default function LeadDashboard() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { leads, summary, isLoading, scoreRules: remoteScoreRules } = useSelector((s) => s.leads);
    const organisation = useSelector((s) => s.orgs?.organisation);
    const [pageMsg, setPageMsg] = useState('');
    const [mergeGroup, setMergeGroup] = useState(null);
    const [mergePrimaryId, setMergePrimaryId] = useState(null);
    const [mergeLoading, setMergeLoading] = useState(false);
    const [mergeError, setMergeError] = useState('');
    const scoreRules = useMemo(() => mergeScoreRules(remoteScoreRules), [remoteScoreRules]);
    const [scoreDialog, setScoreDialog] = useState(false);
    const [scoreForm, setScoreForm] = useState(scoreRules);
    const [scoreSaving, setScoreSaving] = useState(false);

    useEffect(() => {
        dispatch(getLeads());
        dispatch(getLeadSummary());
        dispatch(getOrganisation());
        dispatch(getScoreRules());
    }, [dispatch]);

    const metrics = useMemo(() => {
        const statusCounts = Object.keys(STATUS_CONFIG).reduce((acc, key) => ({ ...acc, [key]: 0 }), {});
        const sourceMap = new Map();
        const ownerMap = new Map();
        let pipelineValue = 0;
        let weightedPipeline = 0;
        let wonValue = 0;
        let dueToday = 0;
        let overdueFollowUps = 0;
        let closeThisWeek = 0;
        let unassigned = 0;

        leads.forEach((lead) => {
            const status = lead.status || 'new';
            const value = Number(lead.budget || 0);
            statusCounts[status] = (statusCounts[status] || 0) + 1;

            if (!terminalStatuses.has(status)) {
                pipelineValue += value;
                weightedPipeline += value * ((STAGE_WEIGHT[status] ?? 10) / 100);
            }
            if (status === 'closed_won') wonValue += value;

            const followUps = getFollowUpCounts(lead);
            dueToday += followUps.dueToday;
            overdueFollowUps += followUps.overdue;

            const closeDays = getDaysBetween(lead.expected_close_date);
            if (closeDays !== null && closeDays >= 0 && closeDays <= 7 && !terminalStatuses.has(status)) {
                closeThisWeek += 1;
            }

            const source = lead.source || 'other';
            const sourceRow = sourceMap.get(source) || { name: source, leads: 0, won: 0, value: 0 };
            sourceRow.leads += 1;
            sourceRow.value += value;
            if (status === 'closed_won') sourceRow.won += 1;
            sourceMap.set(source, sourceRow);

            const owner = getOwnerLabel(lead);
            if (owner === 'Unassigned') unassigned += 1;
            const ownerRow = ownerMap.get(owner) || { name: owner, total: 0, open: 0, won: 0, overdue: 0 };
            ownerRow.total += 1;
            if (!terminalStatuses.has(status)) ownerRow.open += 1;
            if (status === 'closed_won') ownerRow.won += 1;
            ownerRow.overdue += followUps.overdue;
            ownerMap.set(owner, ownerRow);
        });

        const total = summary?.total ?? leads.length;
        const won = summary?.closed_won ?? statusCounts.closed_won ?? 0;
        const lost = summary?.closed_lost ?? statusCounts.closed_lost ?? 0;
        const open = Math.max(total - won - lost, 0);
        const conversionRate = total ? Math.round((won / total) * 100) : 0;

        const statusChart = Object.entries(STATUS_CONFIG)
            .map(([key, config]) => ({ key, name: config.label, value: statusCounts[key] || 0, color: config.color }))
            .filter((item) => item.value > 0);

        const sourceRows = [...sourceMap.values()]
            .sort((a, b) => b.leads - a.leads)
            .slice(0, 6);

        const ownerRows = [...ownerMap.values()]
            .sort((a, b) => b.open - a.open || b.total - a.total)
            .slice(0, 6);

        const recentLeads = [...leads]
            .sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0))
            .slice(0, 5);

        return {
            total, open, won, lost, statusCounts,
            pipelineValue, weightedPipeline, wonValue,
            dueToday: summary?.due_today_followups ?? dueToday,
            overdueFollowUps: summary?.overdue_followups ?? overdueFollowUps,
            closeThisWeek, unassigned, conversionRate,
            statusChart, sourceRows, ownerRows, recentLeads,
        };
    }, [leads, summary]);

    const duplicateGroups = useMemo(() => {
        const buckets = new Map();
        const add = (type, value, lead) => {
            const normalized = type === 'phone' ? normalizePhone(value) : normalizeComparable(value);
            if (!normalized || (type === 'phone' && normalized.length < 7)) return;
            const key = `${type}:${normalized}`;
            if (!buckets.has(key)) buckets.set(key, { type, value, leads: [] });
            buckets.get(key).leads.push(lead);
        };

        leads.forEach((lead) => {
            add('phone', lead.phone, lead);
            add('email', lead.email, lead);
            add('company', lead.company_name, lead);
        });

        return [...buckets.values()].filter((group) => group.leads.length > 1);
    }, [leads]);

    const openMergeDialog = (group) => {
        setMergeGroup(group);
        setMergePrimaryId(group.leads[0].id);
        setMergeError('');
    };

    const closeMergeDialog = () => {
        setMergeGroup(null);
        setMergePrimaryId(null);
        setMergeError('');
    };

    const handleMergeConfirm = async () => {
        if (!mergeGroup || !mergePrimaryId) return;
        const primary = mergeGroup.leads.find((lead) => lead.id === mergePrimaryId);
        const duplicates = mergeGroup.leads.filter((lead) => lead.id !== mergePrimaryId);
        if (!primary || duplicates.length === 0) return;

        const mergeableFields = [
            'company_name', 'contact_person', 'phone', 'email', 'website',
            'country', 'city', 'product_interest', 'budget', 'currency', 'notes',
        ];

        setMergeLoading(true);
        setMergeError('');
        try {
            const filledFrom = {};
            const mergedData = { ...primary };
            mergeableFields.forEach((field) => {
                if (!mergedData[field]) {
                    const source = duplicates.find((lead) => lead[field]);
                    if (source) {
                        mergedData[field] = source[field];
                        filledFrom[field] = source.company_name || `Lead #${source.id}`;
                    }
                }
            });

            if (Object.keys(filledFrom).length > 0) {
                await dispatch(updateLead({ id: primary.id, data: mergedData })).unwrap();
            }

            const filledSummary = Object.entries(filledFrom)
                .map(([field, source]) => `${field} from ${source}`)
                .join(', ');
            const mergeNote = `Merged ${duplicates.length} duplicate lead(s): ` +
                duplicates.map((lead) => `${lead.company_name || lead.id} (#${lead.id})`).join(', ') +
                (filledSummary ? `. Filled fields: ${filledSummary}` : '');
            await dispatch(addLeadActivity({ id: primary.id, data: { type: 'note', note: mergeNote } })).unwrap();
            await Promise.all(duplicates.map((lead) => dispatch(deleteLead(lead.id)).unwrap()));

            setPageMsg(`${duplicates.length} duplicate lead(s) merge ho gaye`);
            closeMergeDialog();
            dispatch(getLeads());
            dispatch(getLeadSummary());
        } catch (err) {
            setMergeError(err || 'Merge nahi ho paya');
        } finally {
            setMergeLoading(false);
        }
    };

    const handleScoreField = (name, value) => {
        setScoreForm((prev) => ({ ...prev, [name]: Number(value) }));
    };

    const handleStageWeight = (status, value) => {
        setScoreForm((prev) => ({
            ...prev,
            stageWeights: { ...prev.stageWeights, [status]: Number(value) },
        }));
    };

    const handleSaveScoreRules = async () => {
        setScoreSaving(true);
        try {
            await dispatch(saveScoreRules(mergeScoreRules(scoreForm))).unwrap();
            setScoreDialog(false);
            setPageMsg('Lead scoring rules update ho gaye (poori team ke liye)');
        } catch (err) {
            setPageMsg(err || 'Score rules save nahi ho paye');
        } finally {
            setScoreSaving(false);
        }
    };

    const handleResetScoreRules = async () => {
        setScoreSaving(true);
        try {
            await dispatch(saveScoreRules(DEFAULT_SCORE_RULES)).unwrap();
            setScoreForm(DEFAULT_SCORE_RULES);
        } catch (err) {
            setPageMsg(err || 'Reset nahi ho paya');
        } finally {
            setScoreSaving(false);
        }
    };

    const handleCopyFormLink = async () => {
        if (!organisation?.slug) {
            setPageMsg('Organisation abhi load nahi hui, thodi der baad try karein');
            return;
        }
        const formUrl = `${window.location.origin}/lead-form/${organisation.slug}`;
        try {
            await navigator.clipboard.writeText(formUrl);
            setPageMsg(`Form link copy ho gaya: ${formUrl}`);
        } catch {
            setPageMsg(`Copy nahi ho paya. Manually copy karein: ${formUrl}`);
        }
    };

    const kpis = [
        { label: 'Total Leads', value: metrics.total, color: '#4f46e5', icon: <BusinessIcon /> },
        { label: 'Open Leads', value: metrics.open, color: '#0891b2', icon: <GroupsIcon /> },
        { label: 'Won Leads', value: metrics.won, color: '#16a34a', icon: <TrendingUpIcon /> },
        { label: 'Lost Leads', value: metrics.lost, color: '#dc2626', icon: <WarningIcon /> },
        { label: 'Due Today', value: metrics.dueToday, color: '#b45309', icon: <EventIcon /> },
        { label: 'Overdue Follow-ups', value: metrics.overdueFollowUps, color: '#b91c1c', icon: <WarningIcon /> },
    ];

    return (
        <Box sx={{ p: 3, bgcolor: '#f8fafc', minHeight: '100%' }}>
            <GlassCard sx={{ mb: 3, background: 'linear-gradient(135deg,#0f172a,#1e3a8a)', color: '#fff' }}>
                <CardContent>
                    <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ md: 'center' }} spacing={2}>
                        <Box>
                            <Typography variant="h5" fontWeight={800}>CRM Dashboard</Typography>
                            <Typography variant="body2" sx={{ opacity: 0.8 }}>
                                Lead performance, follow-ups, ownership, and source overview
                            </Typography>
                        </Box>
                        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                            <Button variant="outlined" startIcon={<BusinessIcon />} onClick={() => navigate('/crm/leads')}
                                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.45)', borderRadius: '10px', textTransform: 'none' }}>
                                Leads List
                            </Button>
                            <Button variant="outlined" startIcon={<RuleIcon />} onClick={() => { setScoreForm(scoreRules); setScoreDialog(true); }}
                                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.45)', borderRadius: '10px', textTransform: 'none' }}>
                                Score Rules
                            </Button>
                            <Button variant="outlined" startIcon={<CopyIcon />} onClick={handleCopyFormLink}
                                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.45)', borderRadius: '10px', textTransform: 'none' }}>
                                Copy Form Link
                            </Button>
                            <Button variant="outlined" startIcon={<PipelineIcon />} onClick={() => navigate('/crm/pipeline')}
                                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.45)', borderRadius: '10px', textTransform: 'none' }}>
                                Pipeline
                            </Button>
                            <Button variant="outlined" startIcon={<CampaignIcon />} onClick={() => navigate('/crm/campaigns')}
                                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,0.45)', borderRadius: '10px', textTransform: 'none' }}>
                                Campaigns
                            </Button>
                            <Button variant="contained" startIcon={<AddIcon />} onClick={() => navigate('/crm/leads')}
                                sx={{ bgcolor: '#fff', color: '#1e3a8a', borderRadius: '10px', textTransform: 'none', fontWeight: 800, '&:hover': { bgcolor: '#f8fafc' } }}>
                                Add Lead
                            </Button>
                        </Stack>
                    </Stack>
                    {isLoading && <LinearProgress sx={{ mt: 2, bgcolor: 'rgba(255,255,255,0.18)', '& .MuiLinearProgress-bar': { bgcolor: '#fff' } }} />}
                </CardContent>
            </GlassCard>

            {pageMsg && <Alert severity="success" sx={{ mb: 2 }} onClose={() => setPageMsg('')}>{pageMsg}</Alert>}

            {duplicateGroups.length > 0 && (
                <Alert severity="warning" sx={{ mb: 3 }}>
                    <Stack spacing={1}>
                        <Typography variant="body2" fontWeight={800}>
                            {duplicateGroups.length} duplicate signal(s) found by phone/email/company
                        </Typography>
                        {duplicateGroups.slice(0, 4).map((group) => (
                            <Stack key={`${group.type}:${group.value}`} direction={{ xs: 'column', sm: 'row' }} spacing={1} justifyContent="space-between" alignItems={{ sm: 'center' }}>
                                <Typography variant="caption" color="text.secondary">
                                    {group.type}: <strong>{group.value}</strong> - {group.leads.map((lead) => lead.company_name || `#${lead.id}`).join(', ')}
                                </Typography>
                                <Button size="small" onClick={() => openMergeDialog(group)} sx={{ textTransform: 'none', alignSelf: { xs: 'flex-start', sm: 'center' } }}>
                                    Review & Merge
                                </Button>
                            </Stack>
                        ))}
                    </Stack>
                </Alert>
            )}

            <Grid container spacing={2} sx={{ mb: 3 }}>
                {kpis.map((item) => (
                    <Grid item xs={12} sm={6} md={4} lg={2} key={item.label}>
                        <GlassCard sx={{ height: '100%' }}>
                            <CardContent sx={{ py: 2 }}>
                                <Stack direction="row" spacing={1.25} alignItems="center">
                                    <Avatar sx={{ width: 40, height: 40, bgcolor: `${item.color}14`, color: item.color }}>
                                        {item.icon}
                                    </Avatar>
                                    <Box sx={{ minWidth: 0 }}>
                                        <Typography variant="h5" fontWeight={900} sx={{ color: item.color }} noWrap>
                                            {item.value}
                                        </Typography>
                                        <Typography variant="caption" color="text.secondary" noWrap>{item.label}</Typography>
                                    </Box>
                                </Stack>
                            </CardContent>
                        </GlassCard>
                    </Grid>
                ))}
            </Grid>

            <Grid container spacing={2} sx={{ mb: 3 }}>
                {[
                    { label: 'Pipeline Value', value: formatMoney(metrics.pipelineValue), hint: 'Open lead budget', color: '#0f766e' },
                    { label: 'Weighted Pipeline', value: formatMoney(metrics.weightedPipeline), hint: 'Stage adjusted value', color: '#4338ca' },
                    { label: 'Won Value', value: formatMoney(metrics.wonValue), hint: `${metrics.conversionRate}% conversion`, color: '#15803d' },
                    { label: 'Close This Week', value: metrics.closeThisWeek, hint: `${metrics.unassigned} unassigned`, color: '#0284c7' },
                ].map((item) => (
                    <Grid item xs={12} md={3} key={item.label}>
                        <GlassCard sx={{ height: '100%' }}>
                            <CardContent>
                                <Typography variant="caption" color="text.secondary">{item.label}</Typography>
                                <Typography variant="h5" fontWeight={900} sx={{ color: item.color, mt: 0.5 }}>
                                    {item.value}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">{item.hint}</Typography>
                            </CardContent>
                        </GlassCard>
                    </Grid>
                ))}
            </Grid>

            <Grid container spacing={2}>
                <Grid item xs={12} lg={5}>
                    <GlassCard sx={{ height: 380 }}>
                        <CardContent sx={{ height: '100%' }}>
                            <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
                                <Box>
                                    <Typography variant="h6" fontWeight={800}>Status Split</Typography>
                                    <Typography variant="caption" color="text.secondary">Lead count by pipeline stage</Typography>
                                </Box>
                                <Chip label={`${metrics.conversionRate}% won`} sx={{ bgcolor: '#dcfce7', color: '#15803d', fontWeight: 800 }} />
                            </Stack>
                            {metrics.statusChart.length > 0 ? (
                                <ResponsiveContainer width="100%" height={285}>
                                    <PieChart>
                                        <Pie data={metrics.statusChart} dataKey="value" nameKey="name" innerRadius={62} outerRadius={105} paddingAngle={2}>
                                            {metrics.statusChart.map((entry) => <Cell key={entry.key} fill={entry.color} />)}
                                        </Pie>
                                        <ChartTooltip />
                                    </PieChart>
                                </ResponsiveContainer>
                            ) : (
                                <Stack alignItems="center" justifyContent="center" sx={{ height: 285, color: 'text.secondary' }}>
                                    <BusinessIcon sx={{ fontSize: 44, color: '#cbd5e1', mb: 1 }} />
                                    <Typography>No lead data yet</Typography>
                                </Stack>
                            )}
                        </CardContent>
                    </GlassCard>
                </Grid>

                <Grid item xs={12} lg={7}>
                    <GlassCard sx={{ height: 380 }}>
                        <CardContent>
                            <Typography variant="h6" fontWeight={800}>Source Performance</Typography>
                            <Typography variant="caption" color="text.secondary">Top sources by lead count and value</Typography>
                        </CardContent>
                        <TableContainer sx={{ maxHeight: 295 }}>
                            <Table stickyHeader size="small">
                                <TableHead>
                                    <TableRow>
                                        {['Source', 'Leads', 'Won', 'Value'].map((head) => (
                                            <TableCell key={head} sx={{ fontWeight: 800, bgcolor: '#fff' }}>{head}</TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {metrics.sourceRows.length === 0 ? (
                                        <TableRow><TableCell colSpan={4} align="center" sx={{ py: 5, color: 'text.secondary' }}>No sources found</TableCell></TableRow>
                                    ) : metrics.sourceRows.map((row) => (
                                        <TableRow key={row.name}>
                                            <TableCell>
                                                <Chip label={row.name.replace('_', ' ').toUpperCase()} size="small"
                                                    sx={{ bgcolor: '#f1f5f9', color: '#334155', fontWeight: 800 }} />
                                            </TableCell>
                                            <TableCell>{row.leads}</TableCell>
                                            <TableCell>{row.won}</TableCell>
                                            <TableCell>{formatMoney(row.value)}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </GlassCard>
                </Grid>

                <Grid item xs={12} lg={7}>
                    <GlassCard>
                        <CardContent>
                            <Typography variant="h6" fontWeight={800}>Owner Workload</Typography>
                            <Typography variant="caption" color="text.secondary">Open leads and overdue work by owner</Typography>
                        </CardContent>
                        <TableContainer component={Paper} elevation={0}>
                            <Table size="small">
                                <TableHead>
                                    <TableRow>
                                        {['Owner', 'Total', 'Open', 'Won', 'Overdue'].map((head) => (
                                            <TableCell key={head} sx={{ fontWeight: 800 }}>{head}</TableCell>
                                        ))}
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {metrics.ownerRows.length === 0 ? (
                                        <TableRow><TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>No owner data found</TableCell></TableRow>
                                    ) : metrics.ownerRows.map((row) => (
                                        <TableRow key={row.name}>
                                            <TableCell>
                                                <Stack direction="row" spacing={1} alignItems="center">
                                                    <Avatar sx={{ width: 28, height: 28, fontSize: 12, bgcolor: row.name === 'Unassigned' ? '#fff7ed' : '#e0e7ff', color: row.name === 'Unassigned' ? '#b45309' : '#4338ca' }}>
                                                        {row.name.charAt(0)}
                                                    </Avatar>
                                                    <Typography variant="body2" fontWeight={700}>{row.name}</Typography>
                                                </Stack>
                                            </TableCell>
                                            <TableCell>{row.total}</TableCell>
                                            <TableCell>{row.open}</TableCell>
                                            <TableCell>{row.won}</TableCell>
                                            <TableCell>
                                                <Chip label={row.overdue} size="small"
                                                    sx={{ bgcolor: row.overdue ? '#fee2e2' : '#f1f5f9', color: row.overdue ? '#b91c1c' : '#64748b', fontWeight: 800 }} />
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </GlassCard>
                </Grid>

                <Grid item xs={12} lg={5}>
                    <GlassCard>
                        <CardContent>
                            <Typography variant="h6" fontWeight={800}>Recent Leads</Typography>
                            <Typography variant="caption" color="text.secondary">Latest entries in the lead list</Typography>
                            <Divider sx={{ my: 1.5 }} />
                            <Stack spacing={1.25}>
                                {metrics.recentLeads.length === 0 ? (
                                    <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>No recent leads</Typography>
                                ) : metrics.recentLeads.map((lead) => {
                                    const status = STATUS_CONFIG[lead.status] || STATUS_CONFIG.new;
                                    return (
                                        <Stack key={lead.id} direction="row" spacing={1.25} alignItems="center"
                                            onClick={() => navigate(`/crm/leads/${lead.id}`)}
                                            sx={{ p: 1, borderRadius: '10px', cursor: 'pointer', '&:hover': { bgcolor: '#f8fafc' } }}>
                                            <Avatar sx={{ bgcolor: status.color, width: 34, height: 34, fontSize: 13 }}>
                                                {lead.company_name?.charAt(0)}
                                            </Avatar>
                                            <Box sx={{ minWidth: 0, flex: 1 }}>
                                                <Typography variant="body2" fontWeight={800} noWrap>{lead.company_name || 'Lead'}</Typography>
                                                <Typography variant="caption" color="text.secondary" noWrap>{lead.contact_person || lead.phone || lead.email || 'No contact added'}</Typography>
                                            </Box>
                                            <Chip label={status.label} size="small" sx={{ bgcolor: status.bg, color: status.color, fontWeight: 700 }} />
                                        </Stack>
                                    );
                                })}
                            </Stack>
                        </CardContent>
                    </GlassCard>
                </Grid>
            </Grid>

            <Dialog open={scoreDialog} onClose={() => setScoreDialog(false)} maxWidth="md" fullWidth
                PaperProps={{ sx: { borderRadius: '16px' } }}>
                <DialogTitle fontWeight={700}>Lead Score & Priority Rules</DialogTitle>
                <DialogContent>
                    <Grid container spacing={2} sx={{ mt: 0.5 }}>
                        {Object.entries(STATUS_CONFIG).map(([status, config]) => (
                            <Grid item xs={12} sm={6} md={4} key={status}>
                                <TextField fullWidth size="small" type="number" label={`${config.label} weight`}
                                    value={scoreForm.stageWeights?.[status] ?? 0}
                                    onChange={(event) => handleStageWeight(status, event.target.value)}
                                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: '10px' } }} />
                            </Grid>
                        ))}
                        {[
                            ['highValueBudget', 'High Value Budget'],
                            ['highValueBonus', 'High Value Bonus'],
                            ['contactBonus', 'Contact Bonus'],
                            ['ownerBonus', 'Owner Bonus'],
                            ['productBonus', 'Product Interest Bonus'],
                            ['closingSoonBonus', 'Closing Soon Bonus'],
                            ['overduePenalty', 'Overdue Penalty'],
                            ['stalePenalty', 'No Next Action Penalty'],
                            ['hotScore', 'Hot Priority Score'],
                            ['warmScore', 'Warm Priority Score'],
                            ['staleDays', 'Stale After Days'],
                        ].map(([key, label]) => (
                            <Grid item xs={12} sm={6} md={4} key={key}>
                                <TextField fullWidth size="small" type="number" label={label}
                                    value={scoreForm[key]} onChange={(event) => handleScoreField(key, event.target.value)}
                                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: '10px' } }} />
                            </Grid>
                        ))}
                    </Grid>
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 2 }}>
                    <Button onClick={handleResetScoreRules} disabled={scoreSaving} sx={{ borderRadius: '10px' }}>Reset</Button>
                    <Button onClick={() => setScoreDialog(false)} disabled={scoreSaving} sx={{ borderRadius: '10px' }}>Cancel</Button>
                    <Button variant="contained" onClick={handleSaveScoreRules} disabled={scoreSaving}
                        startIcon={scoreSaving ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />} sx={{ borderRadius: '10px' }}>
                        {scoreSaving ? 'Saving...' : 'Save Rules'}
                    </Button>
                </DialogActions>
            </Dialog>

            <Dialog open={!!mergeGroup} onClose={closeMergeDialog} maxWidth="sm" fullWidth
                PaperProps={{ sx: { borderRadius: '16px' } }}>
                <DialogTitle fontWeight={700}>Review Duplicate Leads</DialogTitle>
                <DialogContent>
                    {mergeError && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setMergeError('')}>{mergeError}</Alert>}
                    <Alert severity="info" sx={{ mb: 2 }}>
                        Jisko Keep select karoge, wahi lead bachega. Baaki leads se sirf khaali fields fill honge,
                        phir duplicate leads delete ho jaayenge. Summary primary lead par note ke roop me save hogi.
                    </Alert>
                    {mergeGroup && (
                        <RadioGroup value={mergePrimaryId || ''} onChange={(event) => setMergePrimaryId(parseInt(event.target.value, 10))}>
                            <Stack spacing={1.5}>
                                {mergeGroup.leads.map((lead) => (
                                    <Box key={lead.id} sx={{
                                        border: '1px solid',
                                        borderColor: lead.id === mergePrimaryId ? '#6366f1' : '#e5e7eb',
                                        borderRadius: '10px',
                                        p: 1.5,
                                        bgcolor: lead.id === mergePrimaryId ? '#eef2ff' : 'transparent',
                                    }}>
                                        <FormControlLabel
                                            value={lead.id}
                                            control={<Radio size="small" />}
                                            label={
                                                <Box>
                                                    <Typography variant="body2" fontWeight={700}>
                                                        {lead.company_name || `Lead #${lead.id}`}
                                                        {lead.id === mergePrimaryId && (
                                                            <Chip label="Keep" size="small" color="primary" sx={{ ml: 1, height: 18, fontSize: 10 }} />
                                                        )}
                                                    </Typography>
                                                    <Typography variant="caption" color="text.secondary" display="block">
                                                        {lead.contact_person || '-'} - {lead.phone || 'No phone'} - {lead.email || 'No email'}
                                                    </Typography>
                                                    <Typography variant="caption" color="text.secondary">
                                                        Status: {STATUS_CONFIG[lead.status]?.label || lead.status} - Owner: {getUserLabel(lead.owner) || getOwnerLabel(lead)}
                                                    </Typography>
                                                </Box>
                                            }
                                            sx={{ alignItems: 'flex-start', m: 0 }}
                                        />
                                    </Box>
                                ))}
                            </Stack>
                        </RadioGroup>
                    )}
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 2 }}>
                    <Button onClick={closeMergeDialog} sx={{ borderRadius: '10px' }} disabled={mergeLoading}>Cancel</Button>
                    <Button onClick={handleMergeConfirm} variant="contained" sx={{ borderRadius: '10px' }} disabled={mergeLoading}
                        startIcon={mergeLoading ? <CircularProgress size={16} color="inherit" /> : undefined}>
                        {mergeLoading ? 'Merging...' : 'Merge & Delete Duplicates'}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
}
